from django import forms
from .models import Test, TestQueue

class AddTest(forms.ModelForm):

    class Meta:

        model = Test
        fields = [
            "test",
            "command",
            "runs"
            ]

class AddQueue(forms.ModelForm):

    class Meta:

        model = TestQueue
        fields = [
            "test",
            "command",
            ]


class UploadFileForm(forms.Form):
    #title = forms.CharField(max_length=50)
    file = forms.FileField(
        label = 'Select Typology File',
        
        )

        


