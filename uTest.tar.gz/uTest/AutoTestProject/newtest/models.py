from django.db import models
from django.core.urlresolvers import reverse

class Test(models.Model):
    test = models.CharField(max_length = 50)
    command = models.CharField(max_length = 2000)
    runs = models.PositiveIntegerField()

    def __str__(self):
        return self.test

    def get_absolute_detail_url(self):
        return reverse("test:detail", kwargs={"id":self.id})

    def get_absolute_update_url(self):
        return reverse("test:update", kwargs={"id":self.id})

    def get_absolute_delete_url(self):
        return reverse("test:delete", kwargs={"id":self.id})

    def get_absolute_add_url(self):
        return reverse("test:add_to_queue", kwargs={"id":self.id})



class TestQueue(models.Model):
    test = models.CharField(max_length = 50)
    command = models.CharField(max_length = 2000)
    runs = models.PositiveIntegerField()
    #log_path = models.CharField(max_length = 1000)

    def __str__(self):
        return self.test

    def get_absolute_update_url(self):
        return reverse("test:update", kwargs={"id":self.id})

    def get_absolute_detail_url(self):
        return reverse("test:detail", kwargs={"id":self.id})

    def get_absolute_delete_url(self):
        return reverse("test:delete_queue", kwargs={"id":self.id})


class TestLog(models.Model):
    log_path = models.CharField(max_length = 1000)
    log_timestamp = models.DateTimeField(auto_now_add = True)





    
        

