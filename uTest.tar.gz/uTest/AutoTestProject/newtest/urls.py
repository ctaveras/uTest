from django.conf.urls import url, include
from django.views.generic import ListView, DetailView
from newtest.models import Test
from . import views

urlpatterns = [ url(r'^$', views.list_test, name = 'list'), #test home page
                url(r'^add$', views.add_test, name = 'add'), #create test page
                url(r'^(?P<id>\d+)/edit/$', views.update_test, name = 'update'), # update test page
                url(r'^(?P<id>\d+)/delete/$', views.delete_test, name = 'delete'), #delete test page
                url(r'^(?P<id>\d+)/delete_queue/$', views.delete_from_queue, name = 'delete_queue'), #delete test page
                url(r'^(?P<id>\d+)$', views.detail_test, name = 'detail'), #detail test page
                url(r'^queue$', views.test_queue, name = 'queue'), #test queue page
                url(r'^testing$', views.start_queue, name = 'testing'), #test queue start page
                #url(r'^typology$', views.upload_file, name = 'typology'), #typology page
                url(r'^(?P<id>\d+)/add_to_queue/$', views.add_to_queue, name = 'add_to_queue'), #adds to test queue
                ]
