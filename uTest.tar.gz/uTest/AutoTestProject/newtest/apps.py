from django.apps import AppConfig


class NewtestConfig(AppConfig):
    name = 'newtest'
