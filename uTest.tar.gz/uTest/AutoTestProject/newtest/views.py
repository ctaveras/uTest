from django.contrib import messages
from django.shortcuts import render
from django.shortcuts import get_object_or_404, redirect 
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import TestSerializer
from django.http import HttpResponse, HttpResponseRedirect

from .models import Test, TestQueue, TestLog
from .forms import AddTest, AddQueue, UploadFileForm
from subprocess import Popen, PIPE, STDOUT
import os
import json
import subprocess



def add_test(request):
    length_of_queue = len(TestQueue.objects.all())
    form = AddTest(request.POST or None)
    if form.is_valid():
        instance = form.save(commit=False)
        instance.save()
        return HttpResponseRedirect(instance.get_absolute_detail_url())

    context = {
        "title": "Add a Test",
        "form": form,
        "queue_length": length_of_queue,
        }
    return render(request, 'test/add.html', context)

def update_test(request, id=None):
    length_of_queue = len(TestQueue.objects.all())
    try:
        instance = get_object_or_404(Test, id=id)
    except:
        instance = get_object_or_404(TestQueue, id=id)
    form = AddTest(request.POST or None, instance=instance)
    if form.is_valid():
        instance = form.save(commit=False)
        instance.save()
        return HttpResponseRedirect(instance.get_absolute_detail_url())
    
    context = {
        "title": "Update a Test",
        "instance": instance,
        "form": form,
        "queue_length": length_of_queue,
        }
    return render(request, 'test/update.html', context)

def delete_test(request, id=None):
    instance = get_object_or_404(Test, id=id)
    instance.delete()
    return redirect("test:list")

def list_test(request):
    length_of_queue = len(TestQueue.objects.all())
    queryset = Test.objects.all()
    context = {
        "object_list": queryset,
        "title": "List of Tests",
        "queue_length": length_of_queue,
        }
    return render(request, 'test/test_list.html', context)

def detail_test(request, id=None):
    length_of_queue = len(TestQueue.objects.all())
    try:
        instance = get_object_or_404(Test, id=id)
    except:
        instance = get_object_or_404(TestQueue, id=id)
    context = {
        "title": "Details of Test",
        "instance": instance,
        "queue_length": length_of_queue,
        }
    return render(request, 'test/detail.html', context)

def add_to_queue(request, id=None):
    instance = get_object_or_404(Test, id=id)
    
    TestQueue.objects.create(test=instance.test,
                             command=instance.command,
                             runs = instance.runs) 
    return redirect("test:list")

def delete_from_queue(request, id=None):
    instance = get_object_or_404(TestQueue, id=id)
    instance.delete()
    return redirect("test:queue")


def test_queue(request):
    with open('temp.txt', 'w') as typology_file: #clears typology file for resubmission
        typology_file.write('')
        typology_file.close()
        
    length_of_queue = len(TestQueue.objects.all())
    queryset = TestQueue.objects.all()

    if request.method == 'POST':
        form = UploadFileForm(request.POST or None, request.FILES or None)
        print(form.errors)
        if form.is_valid():
            handle_uploaded_file(request.FILES['file'])
            return redirect("test:testing")
    else:
        form = UploadFileForm()
    
    context = {
        "object_list": queryset,
        "title": "Test Queue",
        "queue_length": length_of_queue,
        "form": form
        }    
    return render(request, 'test/test_queue.html', context)





def start_queue(request):
    queryset_queue = TestQueue.objects.all()
    
    length_of_queue = len(TestQueue.objects.all())
    
    temp_commands = TestQueue.objects.all().filter().values_list('command')
    temp_commands = list(temp_commands)
    
    temp_names = TestQueue.objects.all().filter().values_list('test')
    temp_names = list(temp_names)
    
    temp_runs = TestQueue.objects.all().filter().values_list('runs')
    temp_runs = list(temp_runs)
    
    runs = []
    test_names = []
    commands = []
    logs = []

        

    for command in temp_commands: #formats commands from database into an array
        command = list(command)
        commands.append(command)
        

    for name in temp_names: #formats test names from database into an array
        name = list(name)
        test_names.append(name)

    for run in temp_runs: #formats test names from database into an array
        run = list(run)
        runs.append(run)

    final_runs = []
    final_test_names = []
    final_commands = []
    
    for x in range(len(commands)):
        final_runs.append(runs[x][0])
        final_test_names.append(test_names[x][0])
        final_commands.append(commands[x][0])    
    
    failed = [] #list of failed tests
    passed = [] #list of passed tests
    pass_fail = []
    output = [''] #list out test output to log
    test = 0 #test iterator

    username = subprocess.check_output('id -u -n', shell = True)
    username = username.decode('utf-8').rstrip(os.linesep)

    if not os.path.exists('/home/%s/log_files' %username):
        os.makedirs('/home/%s/log_files' %username)

    typology_file = '/home/%s/typology_file.txt' %username
    #print(typology_file)

    for x in range(len(commands)):
        commands[x][0] = commands[x][0].replace('-t typology', '-t %s' %typology_file)
        commands[x][0] = commands[x][0] + ' >> /home/%s/log_files/%s.log' %(username,
                                                                            test_names[x][0].replace(' ','_'))
        
    os.chdir('/home/%s/' %username)
    
    while (test < length_of_queue):  #queue
        
        run_time = 0
        while( run_time < runs[test][0] ):
            
            try:
                output.append(subprocess.check_output('%s' %(commands[test][0]),
                                                            shell = True))                                    
                passed.append(test_names[test][0])
                pass_fail.append('PASSED')
                
            except subprocess.CalledProcessError as command_return:
                failed.append(test_names[test][0])
                print("Test %s Failed" %test_names[test][0])
                pass_fail.append('FAILED')
                
            run_time = run_time + 1

        log = '/home/%s/log_files/%s.log' %(username,
                                            test_names[test][0].replace(' ','_'))
        logs.append(log)
        test = test + 1

    final_query = zip(final_runs, final_test_names,
                      final_commands, logs, pass_fail)
    
    context = {   #webpage context
        "title": "Queue Summary",
        "queue_length": length_of_queue,
        "object_list": final_query,
        "logs": logs,
        }
        
    return render(request, 'test/test_start.html', context)



def handle_uploaded_file(f):
    username = subprocess.check_output('id -u -n', shell = True)
    username = username.decode('utf-8').rstrip(os.linesep)
    
    with open('/home/%s/typology_file.txt' %username, 'wb+') as typology_file:
        for chunk in f.chunks():
            typology_file.write(chunk)
    typology_file.close()
    



class TestList(APIView):

    def get(self, request):
        tests = Test.objects.all()
        serializer = TestSerializer(tests, many=True)
        return Response(serializer.data)

    def post(self):
        pass

    





















        
