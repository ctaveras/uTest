from django.shortcuts import render
from newtest.models import TestQueue

# Create your views here.


def index(request):
    length_of_queue = len(TestQueue.objects.all())
    context = {
        "queue_length": length_of_queue,
        }
    return render(request, 'personal/home.html', context)

def contact(request):
    length_of_queue = len(TestQueue.objects.all())
    queryset = TestQueue.objects.all()
    context = {
        "queue_length": length_of_queue,
        "content": "Email Me @ ctaveras@ebay.com",
        }
    return render(request, 'personal/basic.html', context)





